<template>
  <div class="todo-container">
    <header class="header">
      <h1>ToDoList</h1>
      <div class="input-container">
        <input 
          type="text" 
          v-model="newTodo" 
          placeholder="添加ToDo" 
          @keyup.enter="addTodo"
          class="todo-input"
        />
        <button @click="addTodo" class="add-btn">新增</button>
      </div>
    </header>

    <main>
      <section class="todo-section">
        <h2>正在进行</h2>
        <ul class="todo-list">
          <li v-for="todo in unfinishedTodos" :key="todo.id" class="todo-item">
            <input type="checkbox" @click="markAsFinished(todo.id)" />
            <span class="todo-content">{{ todo.content }}</span>
            <button @click="deleteTodo(todo.id)" class="delete-btn">×</button>
          </li>
        </ul>
      </section>

      <section class="todo-section">
        <h2>已经完成</h2>
        <ul class="todo-list">
          <li v-for="todo in finishedTodos" :key="todo.id" class="todo-item">
            <input type="checkbox" checked @click="markAsUnfinished(todo.id)" />
            <span class="todo-content">{{ todo.content }}</span>
            <button @click="deleteTodo(todo.id)" class="delete-btn">×</button>
          </li>
        </ul>
      </section>
    </main>

    <footer>
      <p>Copyright © 2014 todolist.cn <button @click="clearAll" class="clear-btn">clear</button></p>
    </footer>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import axios from 'axios';

const router = useRouter();
const newTodo = ref('');
const unfinishedTodos = ref([]);
const finishedTodos = ref([]);
const user = ref(null);

// 检查用户是否已登录
onMounted(() => {
  const userStr = localStorage.getItem('user');
  if (!userStr) {
    router.push('/');
    return;
  }
  
  user.value = JSON.parse(userStr);
  fetchTodos();
});

// 获取所有任务
const fetchTodos = async () => {
  try {
    // 获取未完成任务
    const unfinishedResponse = await axios.get(`http://localhost:3000/api/todos/user/${user.value.id}/unfinished`);
    if (unfinishedResponse.data.success) {
      unfinishedTodos.value = unfinishedResponse.data.todos;
    }
    
    // 获取已完成任务
    const finishedResponse = await axios.get(`http://localhost:3000/api/todos/user/${user.value.id}/finished`);
    if (finishedResponse.data.success) {
      finishedTodos.value = finishedResponse.data.todos;
    }
  } catch (error) {
    console.error('获取任务失败:', error);
  }
};

// 添加新任务
const addTodo = async () => {
  if (!newTodo.value.trim()) return;
  
  try {
    const response = await axios.post('http://localhost:3000/api/todos', {
      content: newTodo.value,
      userId: user.value.id
    });
    
    if (response.data.success) {
      // 重新获取任务列表
      fetchTodos();
      newTodo.value = '';
    }
  } catch (error) {
    console.error('添加任务失败:', error);
  }
};

// 标记任务为已完成
const markAsFinished = async (todoId) => {
  try {
    const response = await axios.put(`http://localhost:3000/api/todos/${todoId}/finish`, {
      userId: user.value.id
    });
    
    if (response.data.success) {
      fetchTodos();
    }
  } catch (error) {
    console.error('标记任务完成失败:', error);
  }
};

// 标记任务为未完成
const markAsUnfinished = async (todoId) => {
  try {
    const response = await axios.put(`http://localhost:3000/api/todos/${todoId}/unfinish`, {
      userId: user.value.id
    });
    
    if (response.data.success) {
      fetchTodos();
    }
  } catch (error) {
    console.error('标记任务未完成失败:', error);
  }
};

// 删除任务
const deleteTodo = async (todoId) => {
  try {
    const response = await axios.delete(`http://localhost:3000/api/todos/${todoId}`, {
      data: { userId: user.value.id }
    });
    
    if (response.data.success) {
      fetchTodos();
    }
  } catch (error) {
    console.error('删除任务失败:', error);
  }
};

// 清空所有任务（仅UI效果，实际不删除数据）
const clearAll = () => {
  unfinishedTodos.value = [];
  finishedTodos.value = [];
};
</script>

<style scoped>
.todo-container {
  max-width: 800px;
  min-width: 600px;
  width: 80%;
  margin: 0 auto;
  background-color: #f5f5f5;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  padding: 0;
}

.header {
  background-color: #333;
  color: white;
  padding: 20px 40px;
  width: 100%;
  box-sizing: border-box;
}

.header h1 {
  margin: 0;
  text-align: left;
}

.input-container {
  display: flex;
  margin-top: 10px;
}

.todo-input {
  flex: 1;
  padding: 8px;
  border: none;
  border-radius: 3px;
  margin-right: 10px;
}

.add-btn {
  background-color: #ff6600;
  color: white;
  border: none;
  border-radius: 3px;
  padding: 8px 15px;
  cursor: pointer;
}

.todo-section {
  padding: 20px;
}

.todo-section h2 {
  margin-top: 0;
  color: #333;
  font-size: 18px;
  font-weight: normal;
}

.todo-list {
  list-style: none;
  padding: 0;
  margin: 0;
}

.todo-item {
  display: flex;
  align-items: center;
  background-color: white;
  padding: 10px 15px;
  margin-bottom: 10px;
  border-radius: 3px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.todo-content {
  flex: 1;
  margin: 0 10px;
}

.delete-btn {
  background: none;
  border: none;
  color: #999;
  font-size: 20px;
  cursor: pointer;
}

footer {
  margin-top: auto;
  padding: 10px;
  text-align: center;
  color: #666;
  font-size: 14px;
}

.clear-btn {
  background: none;
  border: none;
  color: #999;
  cursor: pointer;
  text-decoration: underline;
}
</style>