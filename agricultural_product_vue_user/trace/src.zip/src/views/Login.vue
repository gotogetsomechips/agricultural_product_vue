<template>
  <div class="login-container">
    <div class="login-box">
      <h1 class="title">TodoList</h1>
      <div class="form-group">
        <input 
          type="text" 
          v-model="username" 
          placeholder="用户名" 
          class="form-control"
        />
      </div>
      <div class="form-group">
        <input 
          type="password" 
          v-model="password" 
          placeholder="密码" 
          class="form-control"
        />
      </div>
      <div class="form-group">
        <button @click="login" class="btn-login">登录</button>
      </div>
      <div class="form-group">
        <button @click="register" class="btn-register">注册</button>
      </div>
      <p v-if="errorMsg" class="error-message">{{ errorMsg }}</p>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import axios from 'axios';


const router = useRouter();
const username = ref('');
const password = ref('');
const errorMsg = ref('');

const login = async () => {
  if (!username.value || !password.value) {
    errorMsg.value = '用户名和密码不能为空';
    return;
  }
  
  try {
    const response = await axios.post('http://localhost:3000/api/users/login', {
      name: username.value,
      pwd: password.value
    });
    
    if (response.data.success) {
      // 保存用户信息到本地存储
      localStorage.setItem('user', JSON.stringify(response.data.user));
      // 跳转到主页
      router.push('/home');
    } else {
      errorMsg.value = response.data.message || '登录失败';
    }
  } catch (error) {
    console.error('登录请求失败:', error);
    errorMsg.value = error.response?.data?.message || '登录失败，请稍后再试';
  }
};

const register = async () => {
  if (!username.value || !password.value) {
    errorMsg.value = '用户名和密码不能为空';
    return;
  }
  
  try {
    const response = await axios.post('http://localhost:3000/api/users', {
      name: username.value,
      pwd: password.value
    });
    
    if (response.data.success) {
      errorMsg.value = '注册成功，请登录';
    } else {
      errorMsg.value = response.data.message || '注册失败';
    }
  } catch (error) {
    console.error('注册请求失败:', error);
    errorMsg.value = error.response?.data?.message || '注册失败，请稍后再试';
  }
};
</script>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f5f5f5;
}

.login-box {
  width: 350px;
  padding: 30px;
  background-color: white;
  border-radius: 5px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.title {
  text-align: center;
  margin-bottom: 30px;
  color: #333;
}

.form-group {
  margin-bottom: 20px;
}

.form-control {
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 16px;
}

.btn-login, .btn-register {
  width: 100%;
  padding: 10px;
  border: none;
  border-radius: 4px;
  font-size: 16px;
  cursor: pointer;
}

.btn-login {
  background-color: #4caf50;
  color: white;
}

.btn-register {
  background-color: #2196f3;
  color: white;
}

.error-message {
  color: red;
  text-align: center;
  margin-top: 10px;
}
</style>